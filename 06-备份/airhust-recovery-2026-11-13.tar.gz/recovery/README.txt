机载电脑恢复包（airhust）
生成：2026-11-13

目录
  my/square.cpp              我的 square.cpp（7696 B，sha256 4f6f5aa7…）
  pkg/square_mission/        完整 ROS 包（可直接 clone 到工作空间 src）
  official/                  官方仓库快照（main c226fa1 的 src/ 与 shell/）
  scripts/check.sh           到场体检：版本/指纹/参数/进程/磁盘/依赖
  scripts/restore.sh         一键部署：备份→覆盖 square.cpp→catkin_make→打印参数核对
  scripts/rebuild.sh         仓库被删时用：从 official/ 重建工作空间 + 放入我的 cpp + 写实机参数 + 编译

现场用法
  tar xzf airhust-recovery-2026-11-13.tar.gz
  bash recovery/scripts/check.sh        # 先看被改了什么
  bash recovery/scripts/restore.sh      # 需要时恢复

官方快照可用于重建干净工作空间（见 Prac/01-操作卡 的应急预案 L4）

只传包的最短流程（推荐）
  scp airhust-recovery-2026-11-13.tar.gz airhust@192.168.124.33:~
  cd ~ && tar xzf airhust-recovery-2026-11-13.tar.gz
  bash recovery/scripts/check.sh        # 体检
  bash recovery/scripts/restore.sh      # 部署我的 cpp 并编译
  # 然后核对打印出的 if_debug / altitude / 航点数量

仓库被删了怎么办（考核常见情况）
  cd ~ && tar xzf airhust-recovery-2026-11-13.tar.gz
  bash recovery/scripts/rebuild.sh
  # 会做：新建 ~/template2026_ws → 放入 src/template + src/mission + shell/
  #       → 放入我的 square.cpp → 写 square.yaml（if_debug 0 / 5 点 / 边长 1.0）→ catkin_make

注意
  rebuild.sh 只在“缺什么补什么”：已有的包不会被覆盖（会跳过并提示）。
