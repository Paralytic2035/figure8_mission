#!/usr/bin/env bash
# 机载电脑 5 分钟体检（在机上跑：bash check.sh）
set -u
echo "===== 1. 主机 / 启动时间 ====="
hostname; echo -n "启动于: "; uptime -s; echo -n "现在: "; date
echo
echo "===== 2. 仓库版本 ====="
if cd ~/template2026_ws 2>/dev/null; then
  git log --oneline -1
  echo -n "未提交改动文件数: "; git status --short | wc -l
else
  echo "!! ~/template2026_ws 不存在"
fi
echo
echo "===== 3. 关键文件指纹（和我方基线比对）====="
sha256sum src/mission/src/square.cpp src/mission/config/square.yaml src/template/include/template.h 2>/dev/null \
  || sha256sum ~/template2026_ws/src/mission/src/square.cpp ~/template2026_ws/src/mission/config/square.yaml ~/template2026_ws/src/template/include/template.h 2>/dev/null
echo
echo "===== 4. 任务参数 ====="
grep -nE 'if_debug|altitude|err_max' ~/template2026_ws/src/mission/config/square.yaml 2>/dev/null || echo "!! 读不到 yaml"
echo
echo "===== 5. 残留进程 ====="
pgrep -af 'roslaunch|rosmaster|mavros|square|gzserver|gzclient' || echo "  (无)"
echo
echo "===== 6. tmux 会话 ====="
tmux ls 2>/dev/null || echo "  (无)"
echo
echo "===== 7. 磁盘 ====="
df -h ~ | tail -1
echo
echo "===== 8. 编译产物 ====="
ls -l ~/template2026_ws/devel/lib/mission/square 2>/dev/null || echo "  (未编译)"
echo
echo "===== 9. 依赖包 ====="
rospack find fly_demo 2>/dev/null || echo "!! 缺 fly_demo（硬件启动会失败）"
