#!/usr/bin/env bash
# rebuild.sh —— 机上仓库被删/被搞乱时，用离线包重建工作空间并放入我的 square
# 用法：bash recovery/scripts/rebuild.sh
#       WS=~/my_ws bash recovery/scripts/rebuild.sh     # 换工作空间路径
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
BASE="$(dirname "$HERE")"
WS="${WS:-$HOME/template2026_ws}"
MY="$BASE/my/square.cpp"
OFF="$BASE/official"

[ -f "$MY" ]   || { echo "!! 缺 $MY"; exit 1; }
[ -d "$OFF/src" ] || { echo "!! 缺 $OFF/src"; exit 1; }

echo "== 1. 检查工作空间 =="
if [ -d "$WS" ]; then
  echo "   已存在：$WS"
else
  echo "   不存在 → 新建"
  mkdir -p "$WS"
fi
mkdir -p "$WS/src"

echo "== 2. 补齐 src/ 与 shell/ =="
if [ ! -f "$WS/src/CMakeLists.txt" ]; then
  cp "$OFF/src/CMakeLists.txt" "$WS/src/CMakeLists.txt"
  echo "   已放入 src/CMakeLists.txt"
fi
for pkg in template mission; do
  if [ -d "$WS/src/$pkg" ]; then
    echo "   src/$pkg 已存在，跳过（保留原样）"
  else
    cp -R "$OFF/src/$pkg" "$WS/src/$pkg"
    echo "   已放入 src/$pkg"
  fi
done
if [ ! -d "$WS/shell" ]; then
  cp -R "$OFF/shell" "$WS/shell"
  chmod +x "$WS/shell/"*.sh 2>/dev/null || true
  echo "   已放入 shell/"
else
  echo "   shell/ 已存在，跳过"
fi

echo "== 3. 放入我的 square.cpp =="
SRCDIR="$WS/src/mission/src"
[ -d "$SRCDIR" ] || { echo "!! $SRCDIR 不存在，mission 包不完整"; exit 1; }
if [ -f "$SRCDIR/square.cpp" ]; then
  cp "$SRCDIR/square.cpp" "$SRCDIR/square.cpp.before_rebuild"
  echo "   原有 square.cpp 已备份为 square.cpp.before_rebuild"
fi
cp "$MY" "$SRCDIR/square.cpp"
sha256sum "$SRCDIR/square.cpp"

echo "== 4. 写入实机参数 square.yaml =="
CONFDIR="$WS/src/mission/config"
[ -d "$CONFDIR" ] || { echo "!! 缺 $CONFDIR"; exit 1; }
CONF="$CONFDIR/square.yaml"
if [ -f "$CONF" ]; then
  cp "$CONF" "$CONF.bak.$(date +%H%M)"
  echo "   原 yaml 已备份为 square.yaml.bak.$(date +%H%M)"
fi
cat > "$CONF" <<'YAML'
err_max : 0.15
if_debug : 0

# 起飞及所有航点的统一高度 [m]，相对初始位置。
altitude: 0.8

# 航点相对初始位置的 XY 偏移 [m]，按 0 -> 1 -> 2 -> 3 -> 4 执行后降落
waypoints:
  "0":
    x: 0.0
    y: 0.0
  "1":
    x: 1.0
    y: 0.0
  "2":
    x: 1.0
    y: 1.0
  "3":
    x: 0.0
    y: 1.0
  "4":
    x: 0.0
    y: 0.0
YAML
grep -nE 'if_debug|altitude' "$CONF"
echo -n "   航点数量: "; grep -c 'x:' "$CONF"

echo "== 5. 编译 =="
cd "$WS"
catkin_make -j2

echo
echo "== 完成 =="
echo "   工作空间：$WS"
echo "   启动：cd $WS && ./shell/square.sh"
echo "   起飞前确认：if_debug 0 / 航点 5 / 程序打印 '遥控器offboard'"
