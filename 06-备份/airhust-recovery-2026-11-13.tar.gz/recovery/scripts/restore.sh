#!/usr/bin/env bash
# 一键部署：把我方的 square.cpp 放回 mission 包 → 编译 → 打印参数核对
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BASE="${1:-$(dirname "$HERE")}"
SRC="$BASE/my/square.cpp"
WS="${WS:-$HOME/template2026_ws}"
DST="$WS/src/mission/src"
CONF="$WS/src/mission/config/square.yaml"

[ -f "$SRC" ] || { echo "!! 找不到 $SRC（恢复包不完整？）"; exit 1; }
[ -d "$DST" ] || { echo "!! 找不到 $DST（机上没有 mission 包，改走 L3/L4）"; exit 1; }

echo "== 1. 备份现有 square.cpp =="
if [ -f "$DST/square.cpp" ]; then
  if [ -f "$DST/square.cpp.bak" ]; then
    cp "$DST/square.cpp" "$DST/square.cpp.bak.$(date +%m%d%H%M)"
    echo "   已有 .bak，本次备份为 square.cpp.bak.$(date +%m%d%H%M)"
  else
    cp "$DST/square.cpp" "$DST/square.cpp.bak"
    echo "   已备份为 square.cpp.bak"
  fi
fi

echo "== 2. 覆盖为我的版本 =="
cp "$SRC" "$DST/square.cpp"
sha256sum "$DST/square.cpp"

echo "== 3. 编译 =="
cd "$WS" && catkin_make -j2

echo "== 4. 参数核对（起飞前必看）=="
grep -nE 'if_debug|altitude|err_max' "$CONF" || true
echo -n "   航点数量: "; grep -c 'x:' "$CONF" || true
echo
echo "期望：if_debug 0 / altitude 0.8 / 航点 5 个"
echo "若 if_debug 不是 0：sed -i 's/if_debug *: *1/if_debug : 0/' $CONF"
